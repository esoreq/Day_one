---
title: "Coffee Break"
author: "Dr. Eyal Soreq" 
layout: break
teaching: 0
exercises: 0
break: 10
---
