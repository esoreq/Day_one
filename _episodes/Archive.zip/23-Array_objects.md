---
title: "Array objects and Matrix manipulation"
author: "Dr. Eyal Soreq" 
date: "03/06/2021"
teaching: 15
exercises: 0
questions:
- FIXME
objectives:
- FIXME
keypoints:
- FIXME
---


## Links to expand your understanding 

For those interested in learning more...

- [FIXME](https://learn.datacamp.com/courses/conda-essentials)

{% include links.md %}